﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EfCoreCourse.Data; // Именно это пространство имен ожидает Program.cs

public class Student
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public int Age { get; set; }
}

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Student> Students { get; set; }
}